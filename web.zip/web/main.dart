import 'package:angular/angular.dart';
import 'package:praktikertjanst/app_component.template.dart' as ng;
void main() {
  runApp(ng.AppComponentNgFactory);
}