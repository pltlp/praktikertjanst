import 'package:angular/angular.dart';

@Component(
    directives: const [],
    providers: const [],
    selector: 'p-footer',
    styleUrls: const ['footer_component.css'],
    templateUrl: 'footer_component.html')
class FooterComponent {}
