import 'resource.dart';

class Document extends Resource {
  Document();
  Map<String,String> url = {};
  String size;
  String document_type;
}
