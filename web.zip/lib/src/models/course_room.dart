import '../models/resource.dart';

class CourseRoom extends Resource{
  CourseRoom();

  String backgroud_image;
  List<String> video_ids = [];
  List<String> resources_ids = [];
  List<String> document_ids = [];
  List<String> word_ids = [];
}

