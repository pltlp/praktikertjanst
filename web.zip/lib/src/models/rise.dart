import 'resource.dart';

class Rise extends Resource{
  Rise();
  Map<String,String> url = {};
}
