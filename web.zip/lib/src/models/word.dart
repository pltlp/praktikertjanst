import '../models/resource.dart';

class Word extends Resource {
  Word();
  List<String> img_urls = [];
  Map<String, String> alts = {};
}
