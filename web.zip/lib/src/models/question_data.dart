import '../models/quiz.dart';

class QuestionData {
 
 
 
  Map<String, Map <String, Question>> qustions = {};


}
