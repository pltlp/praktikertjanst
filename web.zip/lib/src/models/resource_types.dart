enum ResourceType
{
  rise,
  document,
  courseRoom,
  video,
  quiz

}