import 'resource.dart';

class Video extends Resource{
  Video();
  Map<String,String> url = {};
}
